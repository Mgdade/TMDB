<?php
/**
 * This file is part of the Tmdb PHP API created by Michael Roterman.
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 *
 * @package Tmdb
 * @author Michael Roterman <michael@wtfz.net>
 * @copyright (c) 2013, Michael Roterman
 * @version 0.0.1
 */
namespace Tmdb\Event;

final class TmdbEvents
{
    /** Request */
    const BEFORE_REQUEST = 'tmdb.before_request';
    const REQUEST        = 'tmdb.request';
    const AFTER_REQUEST  = 'tmdb.after_request';

    /** Hydration */
    const BEFORE_HYDRATION = 'tmdb.before_hydration';
    const HYDRATE          = 'tmdb.hydrate';
    const AFTER_HYDRATION  = 'tmdb.after_hydration';
}
