<html>
<body>    	
     <link rel="stylesheet" type="text/css" href="css/UI.css">
   
    <div class="header">
  
       <img src="../TMDB/images/popcorn.png">  
       <h1 id="Title"> My Movie </h1>
    <!-- <p><b><a class="login" href="#login">Login</a></b></p> -->
        <img style="margin-top:-155px; margin-left:410px;" src="../TMDB/images/video-camera.png"> 
        
    </div>
    
    
    <!-- create navigation bar in the home page -->
    <ul>
        <li><a href="Home.php" >Home</a></li>
        <li><a href="Search.php">Search Movies</a></li>
        <li><a href="Favorites.php">My Favorites</a></li>
       <!-- <li><a href="#">My Profile</a></li>  -->
        <li style="float:right"><a class="active" href="#">About</a></li>
    
    </ul>