<?php
// Fill these out when you want to use the examples and rename or copy it to apikey.php 

define('TMDB_API_KEY', '206ebca9df54eb4e60665c640aff3326');
define('TMDB_REQUEST_TOKEN', 'REQUEST_TOKEN'); // for accounts
define('TMDB_SESSION_TOKEN', 'SESSION_TOKEN'); // for accounts
define('TMDB_GUEST_SESSION_TOKEN', 'GUEST_SESSION_TOKEN');     // for guest sessions
define('TMDB_ACCOUNT_ID', 12345);

define('TMDB_LIST_ID', 'LIST_ID');
define('TMDB_USERNAME', 'USERNAME'); // does not function yet, this feature has been announced on forums
define('TMDB_PASSWORD', 'PASSWORD'); // does not function yet, this feature has been announced on forums 